
package raczkowskimartin_programacion2_div322_primerparcial;


public interface Ajustable {
    
    public void ajustar();
    
}
