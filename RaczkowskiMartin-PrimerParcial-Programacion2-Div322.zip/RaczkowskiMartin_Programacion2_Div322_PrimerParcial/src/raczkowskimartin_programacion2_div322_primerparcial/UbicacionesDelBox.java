
package raczkowskimartin_programacion2_div322_primerparcial;


public enum UbicacionesDelBox {
    
    ESTACION,
    MOTOR,
    ESTACION_AERO,
    CARRO_NEUMATICOS    
    
}
