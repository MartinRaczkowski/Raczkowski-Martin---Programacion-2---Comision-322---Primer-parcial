
package raczkowskimartin_programacion2_div322_primerparcial;


public enum CondicionClimatica {
    
    SECO,
    LLUVIA,
    MIXTO
    
    
    
}
